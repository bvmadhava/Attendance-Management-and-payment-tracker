const express = require('express');
const cors = require('cors');
const db = require('./db');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public')); // Make HTML available
const projectRoutes = require('./routes/project');
app.use('/', projectRoutes);



// Test route
app.get('/', (req, res) => {
  db.query('SELECT 1 + 1 AS solution', (err, results) => {
    if (err) return res.status(500).send('DB connection failed');
    res.send(`✅ Database connected! Test result: ${results[0].solution}`);
  });
});

// Signup route
app.post('/signup', (req, res) => {
  const { name, email, phone, address, password } = req.body;

  if (!name || !email || !phone || !address || !password) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const query = 'INSERT INTO users (name, email, phone, address, password) VALUES (?, ?, ?, ?, ?)';
  db.query(query, [name, email, phone, address, password], (err, result) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(400).json({ error: 'Email already registered' });
      }
      console.error('Signup error:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Signup successful', userId: result.insertId });
  });
});

// Login route
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const query = 'SELECT * FROM users WHERE email = ? AND password = ?';
  db.query(query, [email, password], (err, results) => {
    if (err) {
      console.error('Login error:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    if (results.length === 0) {
      return res.status(400).json({ error: 'Invalid email or password' });
    }

    const user = results[0];
    res.json({ message: 'Login successful', userId: user.id, name: user.name });
  });
});

// GET user profile
app.get('/user/:userId', (req, res) => {
  db.query('SELECT id, name, email, phone, address FROM users WHERE id = ?', [req.params.userId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!results.length) return res.status(404).json({ error: 'User not found' });
    res.json(results[0]);
  });
});

// GET all projects for a user
app.get('/projects/:userId', (req, res) => {
  db.query('SELECT id, name, type, deadline FROM projects WHERE user_id = ?', [req.params.userId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});


// POST new project with response insertId
app.post('/projects', (req, res) => {
  const { name, type, user_id, deadline, total_amount } = req.body;

  const sql = 'INSERT INTO projects (name, type, user_id, deadline, total_amount) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, type, user_id, deadline, total_amount], (err, result) => {
    if (err) {
      console.error('Error inserting project:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Project added', insertId: result.insertId });
  });
});



//Update Payments
app.put('/projects/:id/payments', (req, res) => {
  const { id } = req.params;
  const { received, pending } = req.body;

  // First, fetch project type and total_amount
  db.query('SELECT type, total_amount FROM projects WHERE id = ?', [id], (err, results) => {
    if (err || results.length === 0) {
      console.error('Fetch error:', err);
      return res.status(500).json({ error: 'Project not found or error occurred' });
    }

    const { type, total_amount } = results[0];

    if (type === 'contract') {
      const updatedPending = total_amount - received;

      const sql = 'UPDATE projects SET amount_received = ?, pending_amount = ? WHERE id = ?';
      db.query(sql, [received, updatedPending, id], (err, result) => {
        if (err) {
          console.error('Update error:', err);
          return res.status(500).json({ error: 'Update failed' });
        }
        res.json({ message: 'Contract payment updated' });
      });

    } else {
      // For daily-based, both fields come from frontend
      const sql = 'UPDATE projects SET amount_received = ?, pending_amount = ? WHERE id = ?';
      db.query(sql, [received, pending, id], (err, result) => {
        if (err) {
          console.error('Update error:', err);
          return res.status(500).json({ error: 'Update failed' });
        }
        res.json({ message: 'Daily payment updated' });
      });
    }
  });
});




// POST attendance for project on given date
app.post('/project/:projectId/attendance', (req, res) => {
  const { date, presentWorkers } = req.body;
  const pid = req.params.projectId;
  const data = presentWorkers.join(',');
  db.query(
    'INSERT INTO attendance (project_id, date, present_workers) VALUES (?, ?, ?)',
    [pid, date, data],
    (err) => {
      if (err) return res.status(500).json({ error: 'DB' });
      res.json({ message: 'Attendance saved' });
    }
  );
});

// GET attendance dates for project
app.get('/project/:projectId/attendance', (req, res) => {
  const pid = req.params.projectId;
  db.query(
    'SELECT id, date FROM attendance WHERE project_id = ? ORDER BY date DESC',
    [pid],
    (err, results) => {
      if (err) return res.status(500).json({ error: 'DB' });
      res.json(results);
    }
  );
});

// Add worker to workers table
app.post('/project/:id/workers', (req, res) => {
  const pid = req.params.id;
  const { name, type } = req.body;
  const sql = 'INSERT INTO workers (name, category, project_id) VALUES (?, ?, ?)';
  db.query(sql, [name, type, pid], (err, result) => {
    if (err) {
      console.error('Worker insert error:', err);
      return res.status(500).json({ error: 'DB error' });
    }
    res.json({ id: result.insertId, name, type });
  });
});

app.get('/project/:id/workers', (req, res) => {
  const projectId = req.params.id;
  const sql = 'SELECT * FROM workers WHERE project_id = ?';

  db.query(sql, [projectId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database query failed' });
    }
    res.json(results); // Return list of workers
  });
});

// Get attendance details for a specific project and date
app.get('/project/:id/attendance/:date', (req, res) => {
  const pid = req.params.id;
  const date = req.params.date;

  const sql = 'SELECT present_workers FROM attendance WHERE project_id = ? AND date = ?';
  db.query(sql, [pid, date], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ error: "No attendance data found" });

    const presentWorkers = results[0].present_workers
      ? results[0].present_workers.split(',').map(name => name.trim())
      : [];

    const contractSql = 'SELECT name FROM workers WHERE project_id = ? AND category = "contract"';
    const dailySql = 'SELECT name FROM workers WHERE project_id = ? AND category = "daily"';

    db.query(contractSql, [pid], (err, contractResults) => {
      if (err) return res.status(500).json({ error: err.message });

      db.query(dailySql, [pid], (err, dailyResults) => {
        if (err) return res.status(500).json({ error: err.message });

        const contractPresent = contractResults
          .map(w => w.name)
          .filter(name => presentWorkers.includes(name));

        const dailyPresent = dailyResults
          .map(w => w.name)
          .filter(name => presentWorkers.includes(name));

        res.json({
          contract: contractPresent,
          daily: dailyPresent
        });
      });
    });
  });
});




// Get project by ID and include its workers
app.get('/project/:id', (req, res) => {
  const pid = req.params.id;

  const sqlProject = 'SELECT * FROM projects WHERE id = ?';
  const sqlWorkers = 'SELECT name, category FROM workers WHERE project_id = ?';

  db.query(sqlProject, [pid], (err, projectResults) => {
    if (err || projectResults.length === 0) return res.status(500).json({ error: 'Project not found' });

    const project = projectResults[0];

    db.query(sqlWorkers, [pid], (err2, workerResults) => {
      if (err2) return res.status(500).json({ error: 'Error loading workers' });

      project.contractWorkers = workerResults.filter(w => w.category === 'contract').map(w => w.name);
      project.dailyWorkers = workerResults.filter(w => w.category === 'daily').map(w => w.name);

      res.json(project);
    });
  });
});



app.post('/workers', (req, res) => {
  const { name, category, project_id } = req.body;
  const sql = 'INSERT INTO workers (name, category, project_id) VALUES (?, ?, ?)';
  db.query(sql, [name, category, project_id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ id: result.insertId });
  });
});



app.listen(3000, () => {
  console.log('🚀 Server running at http://localhost:3000');
});
